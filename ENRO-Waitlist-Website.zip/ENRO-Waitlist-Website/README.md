# ENRO waitlist

Purple-and-cream waitlist page with clay construction artwork, the ENRO prototype dashboard, responsive layouts, reduced-motion support and a working email signup form. The ENRO wordmark uses Inter at weight 650; page text uses DM Sans.

Website files are in `public/`. Original generated artwork and exact generation prompts are in `artwork/`; the site uses the smaller WebP versions in `public/assets/`. The artwork was created with the built-in image-generation tool. Preview screenshots are in `preview/`.

## Run locally

Install Node.js 22 or later. Open a terminal in this folder and run:

```sh
npm start
```

Open http://127.0.0.1:4180. No dependency installation or build step is required. The same command works on macOS and Windows.

## Signups

The form sends `POST /api/waitlist` with JSON containing `email` and optional `name`, `company`, and `website`. The `website` field is a hidden spam trap and should stay empty. Accepted emails are saved to `data/waitlist.jsonl`; repeated emails are not saved twice. Success returns `{ "ok": true, "message": "You're on the list. We'll be in touch when ENRO is ready." }`. Errors return a non-2xx status with `{ "ok": false, "message": "…" }`.

The signup file is private and excluded from Git. There is no public signup list or export route. Keep this file private and back it up. Sending confirmation or launch emails is not included.

## Deploy

Use a Node host with persistent writable disk and one server instance. Set `HOST=0.0.0.0`, the host's `PORT`, and optionally `WAITLIST_DATA_DIR` to a private persistent folder outside `public`. Run `npm start`; there is no build command. Put HTTPS in front of the app and preserve the public `Host` header when using a reverse proxy.

Static-only or ephemeral/serverless hosting will not preserve signups with this storage design. Multiple server instances need shared database storage instead of the local file. The basic signup rate limit uses the direct connection IP; behind a proxy it may apply to all visitors together.

## Check

```sh
npm test
```

Tests use temporary storage and do not change the real waitlist.
