const form = document.querySelector("#waitlist-form");
const status = document.querySelector("#form-message");
const submitButton = form.querySelector('[type="submit"]');
const submitLabel = submitButton.querySelector(".button-label");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!form.reportValidity() || submitButton.disabled) return;
  submitButton.disabled = true;
  submitLabel.textContent = "Saving your spot…";
  form.setAttribute("aria-busy", "true");
  status.textContent = "";
  status.classList.remove("error");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch("/api/waitlist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: form.email.value.trim(),
        website: form.website.value,
      }),
      signal: controller.signal,
    });
    const result = await response.json();
    if (!response.ok || !result.ok)
      throw new Error(
        result.message || "We couldn’t save your spot. Please try again.",
      );
    form.hidden = true;
    document.querySelector(".signup").classList.add("success");
    status.textContent =
      "You’re on the list. Here’s to building something better.";
  } catch (error) {
    status.classList.add("error");
    status.textContent =
      error.name === "AbortError" || error instanceof TypeError
        ? "We couldn’t connect. Please try again in a moment."
        : error.message;
  } finally {
    clearTimeout(timeout);
    submitButton.disabled = false;
    submitLabel.textContent = "Join the waitlist";
    form.removeAttribute("aria-busy");
  }
});

const privacy = document.querySelector("#privacy-dialog");
document
  .querySelector("#privacy-trigger")
  .addEventListener("click", () => privacy.showModal());
privacy
  .querySelectorAll("button")
  .forEach((button) => button.addEventListener("click", () => privacy.close()));
privacy.addEventListener("click", (event) => {
  if (event.target === privacy) {
    const bounds = privacy.getBoundingClientRect();
    if (
      event.clientX < bounds.left ||
      event.clientX > bounds.right ||
      event.clientY < bounds.top ||
      event.clientY > bounds.bottom
    )
      privacy.close();
  }
});
document.querySelector("#year").textContent = new Date().getFullYear();
if (
  "IntersectionObserver" in window &&
  !window.matchMedia("(prefers-reduced-motion: reduce)").matches
) {
  document.documentElement.classList.add("motion-ready");
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.08 },
  );
  document
    .querySelectorAll(".reveal")
    .forEach((element) => observer.observe(element));
}
