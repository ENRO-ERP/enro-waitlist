import { createServer } from "node:http";
import { mkdir, open, readFile, realpath, stat } from "node:fs/promises";
import {
  dirname,
  extname,
  isAbsolute,
  relative,
  resolve,
  sep,
} from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { randomUUID } from "node:crypto";

const directory = dirname(fileURLToPath(import.meta.url));
const message = "You're on the list. We'll be in touch when ENRO is ready.";
const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
};

function json(response, status, payload, headers = {}) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...headers,
  });
  response.end(JSON.stringify(payload));
}

function error(status, message) {
  return Object.assign(new Error(message), { status });
}

async function readJson(request) {
  if (
    request.headers["content-type"]?.split(";")[0].trim() !== "application/json"
  ) {
    throw error(415, "Please send your details as JSON.");
  }
  if (Number(request.headers["content-length"]) > 8192) {
    request.resume();
    throw error(
      413,
      "Those details are too long. Please shorten them and try again.",
    );
  }
  let size = 0;
  const chunks = [];
  for await (const chunk of request.iterator({ destroyOnReturn: false })) {
    size += chunk.length;
    if (size > 8192) {
      request.resume();
      throw error(
        413,
        "Those details are too long. Please shorten them and try again.",
      );
    }
    chunks.push(chunk);
  }
  try {
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!body || Array.isArray(body) || typeof body !== "object")
      throw new Error();
    return body;
  } catch {
    throw error(400, "Please check your details and try again.");
  }
}

function optionalText(value, maximum, label) {
  if (value == null) return "";
  if (
    typeof value !== "string" ||
    value.length > maximum ||
    /[\u0000-\u001f\u007f]/u.test(value)
  ) {
    throw error(400, `Please enter a valid ${label}.`);
  }
  return value.trim();
}

function signupDetails(body) {
  const email =
    typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const [local, domain, extra] = email.split("@");
  const labels = domain?.split(".") ?? [];
  const validDomain =
    labels.length >= 2 &&
    labels.every(
      (label) =>
        label.length <= 63 && /^[a-z\d](?:[a-z\d-]*[a-z\d])?$/i.test(label),
    );
  if (
    !email ||
    email.length > 254 ||
    !local ||
    local.length > 64 ||
    extra !== undefined ||
    /[\s\u0000-\u001f\u007f<>(),;:"\[\]\\]/u.test(local) ||
    local.startsWith(".") ||
    local.endsWith(".") ||
    local.includes("..") ||
    !validDomain ||
    labels.at(-1).length < 2
  ) {
    throw error(400, "Please enter a valid email address.");
  }
  return {
    email,
    name: optionalText(body.name, 120, "name"),
    company: optionalText(body.company, 160, "company name"),
    website: optionalText(body.website, 2048, "website"),
  };
}

function isWithin(root, file) {
  const path = relative(root, file);
  return (
    path === "" ||
    (!isAbsolute(path) && path !== ".." && !path.startsWith(`..${sep}`))
  );
}

export function createWaitlistServer({
  publicDir = resolve(directory, "public"),
  dataDir = process.env.WAITLIST_DATA_DIR || resolve(directory, "data"),
  rateLimit = 10,
  rateWindowMs = 10 * 60 * 1000,
} = {}) {
  const requests = new Map();
  let storageQueue = Promise.resolve();

  function isRateLimited(request, response) {
    const now = Date.now();
    const address = request.socket.remoteAddress || "unknown";
    for (const [key, value] of requests) {
      if (value.reset <= now) requests.delete(key);
    }
    const entry = requests.get(address) || {
      count: 0,
      reset: now + rateWindowMs,
    };
    entry.count += 1;
    requests.set(address, entry);
    if (entry.count <= rateLimit) return false;
    json(
      response,
      429,
      {
        ok: false,
        message: "Too many attempts. Please try again in a few minutes.",
      },
      {
        "Retry-After": String(Math.ceil((entry.reset - now) / 1000)),
      },
    );
    return true;
  }

  function saveSignup(details) {
    const operation = storageQueue.then(async () => {
      await mkdir(dataDir, { recursive: true, mode: 0o700 });
      const file = resolve(dataDir, "waitlist.jsonl");
      let existing = "";
      try {
        existing = await readFile(file, "utf8");
      } catch (failure) {
        if (failure.code !== "ENOENT") throw failure;
      }
      const records = existing
        .split("\n")
        .filter(Boolean)
        .map((line) => {
          const record = JSON.parse(line);
          if (typeof record.email !== "string")
            throw new Error("Invalid stored signup.");
          return record;
        });
      if (
        records.some((record) => record.email.toLowerCase() === details.email)
      )
        return;
      const record = {
        id: randomUUID(),
        email: details.email,
        name: details.name,
        company: details.company,
        createdAt: new Date().toISOString(),
      };
      const handle = await open(file, "a", 0o600);
      try {
        await handle.writeFile(
          `${existing && !existing.endsWith("\n") ? "\n" : ""}${JSON.stringify(record)}\n`,
          "utf8",
        );
        await handle.sync();
      } finally {
        await handle.close();
      }
    });
    storageQueue = operation.catch(() => {});
    return operation;
  }

  async function handle(request, response) {
    response.setHeader("X-Content-Type-Options", "nosniff");
    response.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    const rawPath = request.url.split("?")[0];
    if (rawPath === "/api/waitlist") {
      if (request.method !== "POST") {
        return json(
          response,
          405,
          { ok: false, message: "Please use the signup form." },
          { Allow: "POST" },
        );
      }
      const origin = request.headers.origin;
      if (origin) {
        let source;
        try {
          source = new URL(origin);
        } catch {
          throw error(403, "Please use the signup form on this website.");
        }
        if (
          !["http:", "https:"].includes(source.protocol) ||
          source.host !== request.headers.host
        ) {
          throw error(403, "Please use the signup form on this website.");
        }
      }
      if (isRateLimited(request, response)) return;
      const details = signupDetails(await readJson(request));
      if (!details.website) {
        try {
          await saveSignup(details);
        } catch {
          return json(response, 503, {
            ok: false,
            message: "We couldn't save your signup. Please try again shortly.",
          });
        }
      }
      return json(response, 200, { ok: true, message });
    }
    if (!["GET", "HEAD"].includes(request.method)) {
      return json(
        response,
        405,
        { ok: false, message: "Method not allowed." },
        { Allow: "GET, HEAD" },
      );
    }
    let pathname;
    try {
      pathname = decodeURIComponent(rawPath);
    } catch {
      throw error(400, "Invalid address.");
    }
    if (
      !pathname.startsWith("/") ||
      pathname.includes("\\") ||
      pathname.includes("\0") ||
      pathname.split("/").some((segment) => segment.startsWith("."))
    ) {
      throw error(403, "This file is not available.");
    }
    const file = resolve(
      publicDir,
      `.${pathname === "/" ? "/index.html" : pathname}`,
    );
    if (!isWithin(publicDir, file))
      throw error(403, "This file is not available.");
    try {
      const [actualRoot, actualFile] = await Promise.all([
        realpath(publicDir),
        realpath(file),
      ]);
      if (!isWithin(actualRoot, actualFile))
        throw error(403, "This file is not available.");
      const info = await stat(actualFile);
      if (!info.isFile()) throw error(404, "Page not found.");
      const contents =
        request.method === "HEAD" ? null : await readFile(actualFile);
      response.writeHead(200, {
        "Content-Type":
          mimeTypes[extname(file).toLowerCase()] || "application/octet-stream",
        "Content-Length": info.size,
        "Cache-Control": "no-cache",
      });
      response.end(contents);
    } catch (failure) {
      if (failure.status) throw failure;
      if (["ENOENT", "ENOTDIR"].includes(failure.code))
        throw error(404, "Page not found.");
      throw failure;
    }
  }

  const server = createServer((request, response) => {
    handle(request, response).catch((failure) => {
      if (!response.headersSent && !response.destroyed) {
        json(response, failure.status || 500, {
          ok: false,
          message: failure.status
            ? failure.message
            : "Something went wrong. Please try again shortly.",
        });
      }
    });
  });
  server.requestTimeout = 15_000;
  server.headersTimeout = 10_000;
  return server;
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  const port = Number(process.env.PORT || 4180);
  const host = process.env.HOST || "127.0.0.1";
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    console.error("PORT must be a number between 1 and 65535.");
    process.exitCode = 1;
  } else {
    const server = createWaitlistServer();
    server.on("error", (failure) => {
      console.error(`Could not start the waitlist website: ${failure.message}`);
      process.exitCode = 1;
    });
    server.listen(port, host, () =>
      console.log(`ENRO waitlist: http://${host}:${port}`),
    );
  }
}
