import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtemp,
  mkdir,
  writeFile,
  readFile,
  rm,
  symlink,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { request } from "node:http";
import { once } from "node:events";
import { createWaitlistServer } from "../server.mjs";

async function fixture(t, options = {}) {
  const root = await mkdtemp(join(tmpdir(), "enro-waitlist-"));
  const publicDir = join(root, "public");
  const dataDir = join(root, "data");
  await mkdir(publicDir);
  await writeFile(join(publicDir, "index.html"), "<h1>ENRO</h1>");
  const server = createWaitlistServer({
    publicDir,
    dataDir,
    rateLimit: 100,
    ...options,
  });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    await rm(root, { recursive: true, force: true });
  });
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = (body, headers = {}) =>
    fetch(`${base}/api/waitlist`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headers },
      body: JSON.stringify(body),
    });
  return { root, publicDir, dataDir, server, base, post };
}

test("saves one normalized signup for simultaneous duplicate emails", async (t) => {
  const { dataDir, post } = await fixture(t);
  const responses = await Promise.all([
    post({ email: " BUILDER@EXAMPLE.COM ", name: " Anya ", company: " ENRO " }),
    post({ email: "builder@example.com" }),
  ]);
  for (const response of responses) {
    assert.equal(response.status, 200);
    assert.equal((await response.json()).ok, true);
  }
  const records = (await readFile(join(dataDir, "waitlist.jsonl"), "utf8"))
    .trim()
    .split("\n")
    .map(JSON.parse);
  assert.equal(records.length, 1);
  assert.equal(records[0].email, "builder@example.com");
  assert.ok(records[0].createdAt);
  assert.ok(records[0].id);
});

test("rejects invalid email and overlong fields, ignores spam-trap submissions", async (t) => {
  const { post, dataDir } = await fixture(t);
  for (const email of [
    "",
    "not-an-email",
    "a@localhost",
    "a@-example.com",
    ".a@example.com",
    "a..b@example.com",
    "a@b.c",
    null,
  ]) {
    const response = await post({ email });
    assert.equal(response.status, 400, String(email));
    assert.equal((await response.json()).ok, false);
  }
  assert.equal(
    (await post({ email: "a@example.com", name: "a".repeat(121) })).status,
    400,
  );
  assert.equal(
    (await post({ email: "bot@example.com", website: "https://spam.example" }))
      .status,
    200,
  );
  await assert.rejects(readFile(join(dataDir, "waitlist.jsonl")), {
    code: "ENOENT",
  });
});

test("fails visibly when signup storage is unavailable", async (t) => {
  const { post, dataDir } = await fixture(t);
  await writeFile(dataDir, "A file cannot be a storage directory.");
  const response = await post({ email: "a@example.com" });
  assert.equal(response.status, 503);
  assert.equal((await response.json()).ok, false);
});

test("serves the website but blocks traversal, private files, and outside symlinks", async (t) => {
  const { base, server, publicDir, root } = await fixture(t);
  assert.equal(await (await fetch(base)).text(), "<h1>ENRO</h1>");
  await writeFile(join(root, "private.txt"), "secret");
  await symlink(join(root, "private.txt"), join(publicDir, "leak.txt"));
  for (const path of [
    "/../private.txt",
    "/%2e%2e/private.txt",
    "/.env",
    "/%2e%2e%5cprivate.txt",
    "/leak.txt",
  ]) {
    const status = await new Promise((resolve, reject) => {
      request(
        { host: "127.0.0.1", port: server.address().port, path },
        (response) => {
          response.resume();
          resolve(response.statusCode);
        },
      )
        .on("error", reject)
        .end();
    });
    assert.equal(status, 403, path);
  }
  assert.equal((await fetch(`${base}/data/waitlist.jsonl`)).status, 404);
  assert.equal((await fetch(`${base}/api/waitlist`)).status, 405);
});

test("rejects cross-origin, oversized, and rate-limited signup requests", async (t) => {
  const { post } = await fixture(t, { rateLimit: 2 });
  assert.equal(
    (
      await post(
        { email: "a@example.com" },
        { Origin: "https://elsewhere.example" },
      )
    ).status,
    403,
  );
  assert.equal(
    (await post({ email: "a@example.com", name: "x".repeat(9000) })).status,
    413,
  );
  assert.equal((await post({ email: "a@example.com" })).status, 200);
  const limited = await post({ email: "b@example.com" });
  assert.equal(limited.status, 429);
  assert.ok(Number(limited.headers.get("retry-after")) > 0);
});
